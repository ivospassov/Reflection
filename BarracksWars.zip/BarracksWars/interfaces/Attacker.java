package BarracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
