package BarracksWars.interfaces;

public interface Executable {

	String execute();

}
