package BarracksWars.interfaces;

public interface Unit extends Destroyable, Attacker {
}
