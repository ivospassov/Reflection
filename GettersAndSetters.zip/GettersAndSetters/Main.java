package GettersAndSetters;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Class reflection = Reflection.class;

        Method[] getters = reflection.getDeclaredMethods();

        Arrays.stream(getters)
                .filter(getter -> getter.getName().startsWith("get") && getter.getParameterCount() == 0)
                .sorted(Comparator.comparing(Method::getName))
                .forEach(getter -> System.out.printf("%s will return class %s%n", getter.getName(), getter.getReturnType()));

        Method[] setters = reflection.getDeclaredMethods();

        Arrays.stream(setters)
                .filter(setter -> setter.getName().startsWith("set") && setter.getParameterCount() == 1)
                .sorted(Comparator.comparing(Method::getName))
                .forEach(setter -> System.out.printf("%s and will set field of class %s%n", setter.getName(), setter.getParameterTypes()[0].getSimpleName()));
    }
}
