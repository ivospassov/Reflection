package Java_OOP.Reflection.Reflection;

import Java_OOP.Reflection.HighQualityMistake.Reflection;

import java.lang.reflect.InvocationTargetException;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class reflection = Reflection.class;
        System.out.println(reflection);

        Class superclass = reflection.getSuperclass();
        System.out.println(superclass);

        Class[] interfaces = reflection.getInterfaces();

        for (Class currentInterface : interfaces) {
            System.out.println(currentInterface);
        }

        Object reflectionObject = reflection.getDeclaredConstructor().newInstance();
        System.out.println(reflectionObject);
    }
}
